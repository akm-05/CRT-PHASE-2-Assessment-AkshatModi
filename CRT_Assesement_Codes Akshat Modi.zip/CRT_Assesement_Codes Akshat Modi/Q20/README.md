# Docker Compose Setup

## Services

### db (PostgreSQL 15)
- Image: `postgres:15`
- Stores data in a named volume `db_data` for persistence
- Configured via environment variables (see `.env`)

### app (myapp:latest)
- Image: `myapp:latest`
- Exposed on host port **8080**
- Starts only **after** the `db` service is up (`depends_on`)
- Receives DB connection details via environment variables

## Usage

### Start services
```bash
docker-compose up -d
```

### Stop services
```bash
docker-compose down
```

### Stop and remove volumes
```bash
docker-compose down -v
```

### View logs
```bash
docker-compose logs -f
```

## Configuration
Edit the `.env` file to change database credentials before starting:

| Variable          | Default      | Description        |
|-------------------|--------------|--------------------|
| `POSTGRES_DB`     | `mydb`       | Database name      |
| `POSTGRES_USER`   | `myuser`     | Database user      |
| `POSTGRES_PASSWORD` | `mypassword` | Database password |
