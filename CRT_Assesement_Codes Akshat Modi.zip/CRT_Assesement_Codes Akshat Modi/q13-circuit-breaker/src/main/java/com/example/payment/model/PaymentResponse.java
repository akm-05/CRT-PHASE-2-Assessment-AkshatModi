package com.example.payment.model;

public class PaymentResponse {
    private String status;
    private double amount;

    public String getStatus() { return status; }
    public void setStatus(String status) { this.status = status; }

    public double getAmount() { return amount; }
    public void setAmount(double amount) { this.amount = amount; }
}
