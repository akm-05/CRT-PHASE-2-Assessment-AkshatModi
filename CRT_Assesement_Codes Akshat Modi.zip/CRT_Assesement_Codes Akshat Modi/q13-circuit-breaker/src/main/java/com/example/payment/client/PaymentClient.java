package com.example.payment.client;

import com.example.payment.model.PaymentResponse;
import io.github.resilience4j.circuitbreaker.annotation.CircuitBreaker;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

@Service
public class PaymentClient {

    @Autowired
    private RestTemplate restTemplate;

    @CircuitBreaker(name = "paymentService", fallbackMethod = "fallbackPayment")
    public PaymentResponse getPayment() {
        return restTemplate.getForObject(
                "http://payment-service/api/payment",
                PaymentResponse.class);
    }

    public PaymentResponse fallbackPayment(Exception e) {
        PaymentResponse response = new PaymentResponse();
        response.setStatus("Payment service unavailable");
        return response;
    }
}
