package com.example.demo;

import com.example.demo.model.Product;
import com.example.demo.repository.ProductRepository;
import com.example.demo.service.ProductService;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.Optional;

import static org.junit.jupiter.api.Assertions.assertEquals;

// Q17: @Mock creates a fake ProductRepository without loading Spring context.
// @InjectMocks injects that mock into ProductService automatically.
// Use this for fast, isolated unit tests.

@ExtendWith(MockitoExtension.class)
public class Q17_ProductServiceMockTest {

    @Mock
    private ProductRepository repo;

    @InjectMocks
    private ProductService service;

    @Test
    public void testGetById() {
        Product product = new Product();
        product.setId(1L);
        product.setName("Laptop");

        Mockito.when(repo.findById(1L)).thenReturn(Optional.of(product));

        Product result = service.getById(1L);

        assertEquals("Laptop", result.getName());
    }
}
