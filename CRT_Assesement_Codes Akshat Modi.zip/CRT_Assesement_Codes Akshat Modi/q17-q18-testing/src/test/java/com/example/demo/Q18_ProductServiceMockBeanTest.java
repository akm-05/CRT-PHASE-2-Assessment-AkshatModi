package com.example.demo;

import com.example.demo.model.Product;
import com.example.demo.repository.ProductRepository;
import com.example.demo.service.ProductService;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;

import java.util.Optional;

import static org.junit.jupiter.api.Assertions.assertEquals;

// Q18: @MockBean registers mock into the Spring context (replaces real bean).
// @Autowired gets the real ProductService but its repo dependency is the mock.
// Use this for integration tests where you need the Spring context running.

@SpringBootTest
public class Q18_ProductServiceMockBeanTest {

    @MockBean
    private ProductRepository repo;

    @Autowired
    private ProductService service;

    @Test
    public void testGetById() {
        Product product = new Product();
        product.setId(1L);
        product.setName("Laptop");

        Mockito.when(repo.findById(1L)).thenReturn(Optional.of(product));

        Product result = service.getById(1L);

        assertEquals("Laptop", result.getName());
    }
}
