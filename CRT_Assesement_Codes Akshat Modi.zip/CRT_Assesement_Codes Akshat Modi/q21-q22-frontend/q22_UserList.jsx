import { useState, useEffect } from "react";

// Q22 Bug: useEffect had no dependency array [] so it ran after every render.
// setUsers() triggered a re-render → infinite loop.
// Fix: Add [] as second arg so effect runs only once on mount.
// Also added loading state to show "Loading..." while data is being fetched.

function UserList() {
    const [users, setUsers] = useState([]);
    const [loading, setLoading] = useState(true);

    useEffect(() => {
        fetch('/api/users')
            .then(res => res.json())
            .then(data => {
                setUsers(data);
                setLoading(false);
            });
    }, []); // <-- Fix: empty array ensures this runs only once

    if (loading) {
        return <p>Loading...</p>;
    }

    return (
        <ul>
            {users.map(u => (
                <li key={u.id}>{u.name}</li>
            ))}
        </ul>
    );
}

export default UserList;
