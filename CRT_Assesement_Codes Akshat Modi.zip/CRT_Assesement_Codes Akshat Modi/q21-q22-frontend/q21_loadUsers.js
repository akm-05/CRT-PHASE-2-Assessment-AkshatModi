// Q21: Fetch users from GET /api/users and render into <ul id="user-list">
// On failure, display error in <p id="error">

async function loadUsers() {
    try {
        const response = await fetch('/api/users');

        if (response.ok) {
            const users = await response.json();
            const userList = document.getElementById('user-list');
            userList.innerHTML = '';
            users.forEach(user => {
                userList.innerHTML += `<li>${user.name}</li>`;
            });
        } else {
            document.getElementById('error').innerText = 'Failed to load users';
        }

    } catch (error) {
        document.getElementById('error').innerText = 'Something went wrong';
    }
}
